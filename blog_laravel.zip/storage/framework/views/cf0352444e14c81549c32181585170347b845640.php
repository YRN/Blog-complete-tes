<?php $__env->startSection('content'); ?>

<?php if(count($errors)> 0): ?>
<ul class="list-group">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="list-group-item text-danger">
        <?php echo e($error); ?>

    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Create a new User
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('users.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title">User</label>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Email</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <div class="text-center">
                    <button class="btn btn-success" type="submit">Add User</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/users/create.blade.php ENDPATH**/ ?>