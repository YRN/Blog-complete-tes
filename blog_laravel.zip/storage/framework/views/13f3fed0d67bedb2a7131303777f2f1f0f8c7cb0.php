<?php $__env->startSection('content'); ?>

<?php if(count($errors)> 0): ?>
<ul class="list-group">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="list-group-item text-danger">
        <?php echo e($error); ?>

    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Edit Your Profile
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('users.profile.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title">Username</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">New Password</label>
                <input type="text" name="password" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Upload New Avatar</label>
                <input type="file" name="avatar" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Facebook Profile</label>
                <input type="text" name="facebook" value="<?php echo e($user->profile->facebook); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Youtube Profile</label>
                <input type="text" name="youtube" value="<?php echo e($user->profile->youtube); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="content">About You</label>
                <textarea class="form-control" name="about" id="about" cols="5"
                    rows="5"><?php echo e($user->profile->about); ?></textarea>
            </div>
            <div class="form-group">
                <div class="text-center">
                    <button class="btn btn-success" type="submit">Update Profile</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/users/profile.blade.php ENDPATH**/ ?>