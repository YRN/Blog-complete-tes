<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <th>Image</th>
                <th>Title</th>
                <th>Restore</th>
                <th>Destroy</th>
            </thead>
            <tbody>
                <?php if($post->count() > 0): ?>
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e($posts->featured); ?>" alt="<?php echo e($posts->title); ?>" width="50px" height="50px">

                    </td>
                    <td>
                        <?php echo e($posts->title); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('post.restore',['id'=>$posts->id])); ?>" class="btn btn-sm btn-success">
                            Restore</a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('post.kill',['id'=>$posts->id])); ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <th colspan="5" class="text-center">No trashed posts</th>
                <?php endif; ?>
            </tbody>

        </table>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/posts/trash.blade.php ENDPATH**/ ?>