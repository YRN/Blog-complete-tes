<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <th>Tag Name</th>
                <th>Edit</th>
                <th>Trashed</th>
            </thead>
            <tbody>
                <?php if($tags->count() > 0): ?>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($tag->tag); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('tags.edit',['id'=>$tag->id])); ?>" class="btn btn-sm btn-info">
                            Edit</a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('tags.delete',['id'=>$tag->id])); ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <th colspan="5" class="text-center">No Tags yet</th>
                <?php endif; ?>
            </tbody>

        </table>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/tags/index.blade.php ENDPATH**/ ?>