<?php $__env->startSection('content'); ?>


<div class="col-lg-3">
    <div class="card bg-primary mb-3 mx-auto">
        <div class="card-header">
            Published Posts
        </div>
        <div class="card-body">
            <h1 class="text-center">
                <?php echo e($posts_count); ?>

            </h1>
        </div>
    </div>
    <div class="card bg-danger mb-3 mr-0">
        <div class="card-header">
            Trashed Posts
        </div>
        <div class="card-body">
            <h1 class="text-center">
                <?php echo e($trashed_count); ?>

            </h1>
        </div>
    </div>
    <div class="card bg-success mb-3">
        <div class="card-header">
            user
        </div>
        <div class="card-body">
            <h1 class="text-center">
                <?php echo e($users_count); ?>

            </h1>
        </div>
    </div>
    <div class="card bg-primary mb-3">
        <div class="card-header">
            categories
        </div>
        <div class="card-body">
            <h1 class="text-center">
                <?php echo e($categories_count); ?>

            </h1>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/home.blade.php ENDPATH**/ ?>