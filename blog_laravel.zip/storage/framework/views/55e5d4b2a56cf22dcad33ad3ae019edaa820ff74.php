<?php $__env->startSection('content'); ?>

<?php if(count($errors)> 0): ?>
<ul class="list-group">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="list-group-item text-danger">
        <?php echo e($error); ?>

    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Edit Your Site Settings
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('settings.update',['id'=>$settings->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title">Site Name</label>
                <input type="text" name="site_name" value="<?php echo e($settings->site_name); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Address</label>
                <input type="text" name="address" value="<?php echo e($settings->address); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Contact Number</label>
                <input type="text" name="contact_number" value="<?php echo e($settings->contact_number); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label for="title">Contact Email</label>
                <input type="text" name="contact_email" value="<?php echo e($settings->contact_email); ?>" class="form-control">
            </div>
            <div class="form-group">
                <div class="text-center">
                    <button class="btn btn-success" type="submit">Update Site Settings</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/settings/settings.blade.php ENDPATH**/ ?>