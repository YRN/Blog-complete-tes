<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <th>Image</th>
                <th>Name</th>
                <th>Permissions</th>
                <th>Delete</th>
            </thead>
            <tbody>
                <?php if($users->count() > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e(asset($user->profile->avatar)); ?>" alt="" width="60px" height="60px"
                            style="border-radius:50%;">
                    </td>
                    <td>
                        <?php echo e($user->name); ?>

                    </td>
                    <td>
                        <?php if($user->admin): ?>

                        <a href="<?php echo e(route('users.not.admin' ,['id'=>$user->id])); ?>" class="btn btn-sm btn-danger">Remove
                            Permissions</a>

                        <?php else: ?>

                        <a href="<?php echo e(route('users.admin' ,['id'=>$user->id])); ?>" class="btn btn-sm btn-success">Make
                            Admin</a>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(Auth::id() !== $user->id): ?>
                        <a href="<?php echo e(route('users.delete' ,['id'=>$user->id])); ?>"
                            class="btn btn-sm btn-danger">Delete</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <th colspan="5" class="text-center">No users yet</th>
                <?php endif; ?>
            </tbody>

        </table>

    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\blog_Laravel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>